﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;

namespace ConexaoBD
{
    public partial class PaginaTabela : Form
    {
        int pos, codigo;

        SqlConnection conecta = new SqlConnection
            (@"Data Source=WIN11\SQLEXPRESS;Initial Catalog=DB_Jogadores_Xadrez;Integrated Security=True");
        SqlCommand sqlCommand = new SqlCommand();
        SqlDataReader reader;
        DataTable dataTable = new DataTable ("TB_Jogadores");
        public PaginaTabela()
        {
            InitializeComponent();
        }

        private void PaginaTabela_Load(object sender, EventArgs e)
        {
            conecta.Open();
            sqlCommand.Connection = conecta;

            try
            {
                MessageBox.Show("Conexão Bem Sucedida!");
            }
            catch
            {
                MessageBox.Show("Não foi possível conectar ao banco de dados!");
            }

            sqlCommand.CommandType = CommandType.Text;
            carregaDados();

            if (dataTable.Rows.Count < 0)
            {
                MessageBox.Show("Não há registros nessa tabela, cadastre um!");

            }else
            {
                navega();
                lblTotalRegistros.Text = Convert.ToString(dataTable.Rows.Count);
            }
        }   
        private void navega()
        {
            if (dataTable.Rows.Count > 0)
            {
                txtId.Text = dataTable.Rows[pos]["id_jogador"].ToString();
                txtNome.Text = dataTable.Rows[pos]["nome"].ToString();
                txtRating.Text = dataTable.Rows[pos]["rating"].ToString();
                txtFederacao.Text = dataTable.Rows[pos]["federacao"].ToString();
            }
            else
            {
                txtId.Text = "";
                txtNome.Text = "";
                txtRating.Text = "";
                txtFederacao.Text = "";
                MessageBox.Show("Ainda não existem dados no banco!", "Grave um Jogador!");
            }


        }
        private void carregaDados()
        {
            sqlCommand.CommandText = "select * from TB_Jogadores";
            reader = sqlCommand.ExecuteReader();
            dataTable.Clear();
            dataTable.Load(reader);
            pos = 0;
            lblTotalRegistros.Text = dataTable.Rows.Count.ToString();
            dataGridView1.DataSource = dataTable;
        }
            
        private void botoes(Boolean ativar)
        {
            btnAnterior.Enabled = ativar;
            btnEditar.Enabled = ativar;
            btnExcluir.Enabled = ativar;
            btnGravar.Enabled = !ativar;
            btnNovo.Enabled = ativar;
            btnPrimeiro.Enabled = ativar;
            btnProximo.Enabled = ativar;
            btnUltimo.Enabled = ativar;
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conecta;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into TB_Jogadores (id_jogador,nome,rating,federacao) values(@id_jogador,@nome,@rating,@federacao)";

            cmd.Parameters.Add(new SqlParameter("@id_jogador", this.txtId.Text));
            try
            {
                int rating = Convert.ToInt32(txtRating.Text);
                if (rating < 100)
                {
                    MessageBox.Show("O rating deve ser maior que 100", "O rating mínimo oficial é 100.");
                    return;
                }
                else
                {
                    cmd.Parameters.Add(new SqlParameter("@rating", this.txtRating.Text));
                }
            }
            catch
            {
                MessageBox.Show("O rating deve conter apenas números!");
                return;
            }
            if (txtNome.Text.Length > 0)
            {
                cmd.Parameters.Add(new SqlParameter("@nome", this.txtNome.Text));
            }
            else
            {
                MessageBox.Show("O nome não pode ser vazio!");
                return;
            }
            
            if(txtFederacao.Text.Length == 3)
            {
                if (txtFederacao.Text.All(char.IsLetter))
                {
                    cmd.Parameters.Add(new SqlParameter("@federacao", this.txtFederacao.Text.ToUpper()));
                }
                else
                {
                    MessageBox.Show("A federação deve conter apenas letras!");
                    return ;
                }
                
            }
            else
            {
                MessageBox.Show("A federação deve ser a abreviação do nome do país em 3 Letras (ex: BRA, USA, NOR, etc...)");
                return;
            }

                cmd.ExecuteNonQuery();
            MessageBox.Show("Dados cadastrados com sucesso!", "Inclusão");
            carregaDados();
            navega();
            botoes(true);
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            botoes(true);
            
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conecta;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update TB_Jogadores set nome=@nome,rating=@rating,federacao=@federacao where id_jogador=@id_jogador";

            try
            {
                int rating = Convert.ToInt32(txtRating.Text);
                if (rating < 100)
                {
                    MessageBox.Show("O rating deve ser maior que 100", "O rating mínimo oficial é 100.");
                    return;
                }
                else
                {
                    cmd.Parameters.AddWithValue("@rating", this.txtRating.Text);
                }
            }
            catch
            {
                MessageBox.Show("O rating deve conter apenas números!");
                return;
            }
            cmd.Parameters.AddWithValue("@id_jogador", this.txtId.Text);
            if (txtNome.Text.Length > 0)
            {
                cmd.Parameters.AddWithValue("@nome", this.txtNome.Text);
            }
            else
            {
                MessageBox.Show("O nome não pode ser vazio!");
                return ;
            }
            if (txtFederacao.Text.Length == 3)
            {
                if (txtFederacao.Text.All(char.IsLetter))
                {
                    cmd.Parameters.AddWithValue("@federacao", this.txtFederacao.Text.ToUpper());
                }
                else
                {
                    MessageBox.Show("A federação deve conter apenas letras!");
                    return;
                }

            }
            else
            {
                MessageBox.Show("A federação deve ser a abreviação do nome do país em 3 Letras (ex: BRA, USA, NOR, etc...)");
                return;
            }

            

            cmd.ExecuteNonQuery();
            MessageBox.Show("Dados atualizados com sucesso!", "Atualização");
            carregaDados();
            navega();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conecta;
            cmd.CommandType = CommandType.Text;

            if (MessageBox.Show("Tem Certeza que deseja excluir esse registro?", "Exclusão", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                cmd.CommandText = "delete from TB_Jogadores where id_jogador=@id_jogador";
                cmd.Parameters.Add(new SqlParameter("@id_jogador", this.txtId.Text));
                cmd.ExecuteNonQuery();  
                carregaDados();
                navega();
                botoes(true);
            }
        }

        private void btnPrimeiro_Click(object sender, EventArgs e)
        {
            pos = 0;
            navega();
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if(pos > 0)
            {
                pos--;
            }
            else
            {
                MessageBox.Show("Esse é o primeiro registro!", "Aviso");
                pos = 0;
            }
            navega();
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if(pos < dataTable.Rows.Count - 1)
            {
                pos++;
            }
            else
            {
                MessageBox.Show("Esse é o último registro!", "Aviso");
                pos = dataTable.Rows.Count - 1;
            }
            navega();
        }

        private void btnUltimo_Click(object sender, EventArgs e)
        {
            pos = dataTable.Rows.Count - 1;
            navega() ;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (dataTable.Rows.Count <= 0)
            {
                txtId.Text = "1";
                    
            }
            else
            {
                codigo = Convert.ToInt32(dataTable.Rows[dataTable.Rows.Count - 1]["id_jogador"]);
                txtNome.Clear();
                txtNome.Clear();
                txtRating.Clear();
                txtFederacao.Clear();
                txtId.Text = (dataTable.Rows[dataTable.Rows.Count - 1]["id_jogador"]).ToString();
                txtId.Focus();
            }
            botoes(false);  
            
        }
    }
}
